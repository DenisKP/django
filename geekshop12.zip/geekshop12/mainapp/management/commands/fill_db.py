import json

from django.core.management.base import BaseCommand

from authapp.models import ShopUser
from mainapp.models import Product, ProductCategory


def load_from_json(file_name):
    with open(file_name, encoding='utf-8') as infile:
        return json.load(infile)


class Command(BaseCommand):
    help = 'Fill data in db'

    def handle(self, *args, **options):
        items = load_from_json('mainapp/json/categories.json')
        for item in items:
            ProductCategory.objects.create(**item)

        # items = load_from_json('mainapp/json/products.json')
        # for item in items:
        #     category = ProductCategory.objects.get(name=item['category'])
        #     item['category'] = category
        #     Product.objects.create(**item)

        if not ShopUser.objects.filter(username='django').exists():
            ShopUser.objects.create_superuser('django', 'django@gb.local', 'geekbrains')


# from django.core.management.base import BaseCommand
# import json
#
# from authapp.models import ShopUser
# from mainapp.models import Product, ProductCategory
#
#
# def load_from_json(file_name):
#     with open(file_name, encoding='utf-8') as infile:
#         return json.load(infile)
#
#
# class Command(BaseCommand):
#     help = 'Fill data in db from json'
#
#     def handle(self, *args, **options):
#         items = load_from_json('mainapp/fixtures/json/categories.json')
#         for item in items:
#             ProductCategory.objects.create(**item)
#
#         items = load_from_json('mainapp/fixtures/json/products.json')
#         for item in items:
#             category = ProductCategory.objects.get(name=item['category'])
#             item['category'] = category
#             Product.objects.create(**item)
#
#         if not ShopUser.objects.filter(username='django').exists():
#             ShopUser.objects.create_superuser('django', 'django.local', 'geekbrains', age=37)

# import json
# import os
#
# from django.contrib.auth.models import User
# from django.core.management.base import BaseCommand
#
# from authapp.models import ShopUser
# from mainapp.models import ProductCategory, Product
#
# JSON_PATH = 'mainapp/fixtures/json'
#
#
# def load_from_json(file_name):
#     with open(os.path.join(JSON_PATH, file_name + '.json'), 'r') as infile:
#         return json.load(infile)
#
#
# class Command(BaseCommand):
#     def handle(self, *args, **options):
#         categories = load_from_json('categories')
#
#         ProductCategory.objects.all().delete()
#         for category in categories:
#             new_category = ProductCategory(**category)
#             new_category.save()
#
#         products = load_from_json('products')
#
#         Product.objects.all().delete()
#         for product in products:
#             category_name = product["category"]
#             # Получаем категорию по имени
#             _category = ProductCategory.objects.get(name=category_name)
#             # Заменяем название категории объектом
#             product['category'] = _category
#             new_product = Product(**product)
#             new_product.save()
#
#         # Создаем суперпользователя при помощи менеджера модели
#         super_user = ShopUser.objects.create_superuser('django', 'django@geekshop.local', 'geekbrains', age=38)
#
