from django.db import models


class ProductCategory(models.Model):
    name = models.CharField('name', max_length=70, unique=True)
    description = models.TextField('description', blank=True)
    short_desc = models.CharField('short description', max_length=200, default='')
    eng_name = models.CharField('name', max_length=70, unique=True, blank=True)
    is_active = models.BooleanField('активности', db_index=True, default=True)

    # def __str__(self):
    #     return f'{self.name}'

    class Meta:
        verbose_name = 'Категория продукта'
        verbose_name_plural = 'Категории продукта'
        ordering = ['name']

    def delete(self, using=None, keep_parents=False):
        self.is_active = False
        self.save(using=using)


class Product(models.Model):
    name = models.CharField('name', max_length=64)
    image = models.ImageField(upload_to='products_images', blank=True)
    description = models.TextField('description', blank=True)
    short_desc = models.TextField('short description', max_length=150, blank=True)
    price = models.DecimalField('price', max_digits=9, decimal_places=2, default=0)
    quantity = models.PositiveIntegerField('quantity on stock', default=0)
    category = models.ForeignKey(ProductCategory, on_delete=models.CASCADE)
    is_active = models.BooleanField('активности', db_index=True, default=True)

    # def __str__(self):
    #     return f'{self.name} ({self.category.name})'

    @classmethod
    def get_items(cls):
        return cls.objects.select_related('category').filter(is_active=True, category__is_active=True)

    class Meta:
        verbose_name = 'Продукт'
        verbose_name_plural = 'Продукты'
        ordering = ['name']
